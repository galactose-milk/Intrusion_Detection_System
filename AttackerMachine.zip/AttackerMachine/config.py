# config.py
# Common configuration for attacker scripts

# For now we attack the same machine, so localhost
TARGET_IP = "127.0.0.1"   # later change to victim laptop IP, e.g. "192.168.1.50"
TARGET_PORT = 8000        # FastAPI port

# Full base URL of your IDS backend
BASE_URL = f"http://{TARGET_IP}:{TARGET_PORT}"
